This directory contains proposals in various states.  Note that we're
not committed to making any of the changes in these proposals, and we
may have also decided they are a bad idea.  Until one of these gets
pulled into the main docs directory, assume they aren't going to happen.
