This is placeholder for documentation related to Swift local refactoring.
It will be expanded soon..
