
This test is just a split version of Prims.swift. The reason why this is here is
to provide at least 1 multi-source benchmark for the purpose of validating that
the multi-source benchmarks can build successfully.
